export default function AboutPage() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="text-2xl font-extrabold text-slate-900">À propos</h1>
      <p className="mt-4 text-slate-700">Page à compléter.</p>
    </div>
  );
}
